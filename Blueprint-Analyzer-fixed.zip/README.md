# Blueprint Analyzer

A mobile-friendly, read-only Deriv synthetic market dashboard.

## Features
- Live public Deriv tick stream
- Market selector
- Matches / Differs analysis
- Target digit selector
- Recent tick distribution
- Automatic reconnect
- Live price, last digit, tick count and latency

## Important
This project is an analysis/visualisation tool. It does not place trades or guarantee outcomes.

The live market-data connection uses Deriv's public WebSocket market-data service. See:
https://developers.deriv.com/docs/data/ticks/
